
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
//This is the Controller for codeigniter crud using ajax application.
class staff_controller extends CI_Controller {
 
public function __construct()
        {
            parent::__construct();
            $this->load->helper('url');
            $this->load->library('email');
        }

        public function all_staff()
        {
            $query= $this->db->query("select staff.*, login.role,login.email,login.status as loginstatus  from staff inner join login on staff.login_id=login.id where login.email!='admin@gmail.com' and login.status!=2");

        $staff= $query->result();
        return $staff;
        }


 public function randompassword()
        {
             $permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
             // Output: 54esmdr0qf
            $password= substr(str_shuffle($permitted_chars), 0, 5);
            return $password;
        }


       



 public function index()
    {
             if($this->session->userdata('logged_in'))
        {

            $session_data = $this->session->userdata('logged_in');
            $staff['id'] = $session_data['id'];
            $staff['email'] = $session_data['email'];
            $staff['role'] = $session_data['role'];



           if($staff['email']!=='admin@gmail.com')
          {

             $user['Systemuser'] = $session_data['Systemuser'];
            $myname=$user['Systemuser']['0']["fullname"];
            $staff['Systemuser'] =$myname;

            $user['Systemuserphoto'] = $session_data['Systemuserphoto'];
            $myphoto=$user['Systemuserphoto']['0']["photo"];
            $staff['Systemuserphoto'] =$myphoto;

             }
            else
            {
            $staff['Systemuser'] ='System Administrator';
            $staff['Systemuserphoto'] =0;

            }
       
            $staff['members']=$this->all_staff();
            
            $page['page'] = 'staff';
            $this->load->view('admin/' . $page['page'] , $staff);

        }
        else
        {
        //If no session, redirect to login page
        redirect('login', 'refresh');
        }
    }


//`email`, `password`, `isLogin`, `role`,

    public function validate_email($usermail)
{
    $query=$this->db->query("select * from login where email='$usermail' "); 
           $result=$query->num_rows();
        if($result >=1)
        {
                return 1;
        }
        else
        {
                return 0;
        }
}

public function addtostafftable($SurName,$OtherName,$gender,$new_staff_id)
        {


            $data = array(
                'firstname' => $OtherName,
                'lastname' => $SurName,
                'gender' => $gender,
                'status' =>0,
                'login_id' => $new_staff_id
                );
            
             $this->db->insert('staff', $data);
            return 'inserted';
             
        }


public function addmember()
        {            
              $usermail=$this->input->post('email');
              $passrandom=$this->randompassword();
              $passwordCombination = $usermail . $this->input->post('role');
              $pass = hash('sha512', $passwordCombination);
             // var_dump($usermail); die;  
            $data=array(
                'email' => $this->input->post('email'),
                'password' => $pass,
                'isLogin' => 0,
                'role' => $this->input->post('role')
             );
            //var_dump($data); die;

            $result=$this->validate_email($usermail);


             if($result=='1')
               {
                // echo $result; die;
                 $notification=array(
                              'message'=>'A Staff with Email Address Exist Already',
                              'alert-type'=>'error'
                            );
                            $this->session->set_flashdata($notification);
                             redirect('staff');
             
               }
           else{ 
      
                $this->db->insert('login', $data); 

                $query=$this->db->query("select id as id from login where email='$usermail' "); 
                 $results = $query->row();
                 $new_staff_id=$results->id;

                  $SurName=$this->input->post('SurName');
                  $OtherName=$this->input->post('OtherName');
                  $gender=$this->input->post('gender');
                  $result=$this->addtostafftable($SurName,$OtherName,$gender,$new_staff_id);
                   $notification=array(
                              'message'=>'New Staff Added Successful',
                              'alert-type'=>'success'
                            );
                            $this->session->set_flashdata($notification);
               redirect('staff');
               //echo $result; die;
                }
              
                
        }


 public   function editmember()
    {       
        $id=$this->input->post("txtid");
        $role=$this->input->post("role");
      
        $data = array(
            'firstname' => $this->input->post('FirstName'),
             'othername' => $this->input->post('OtherName'),
              'lastname' => $this->input->post('LastName'),
             'dob' => $this->input->post('dob'),
              'gender' => $this->input->post('gender'),
             'contact1' => $this->input->post('txtcontact1'),
              'contact2' => $this->input->post('txtcontact2'),
             'homeaddress' => $this->input->post('txthomeaddress'),
             );

        $login = array(
            'role' => $this->input->post('role')
             );
        $this->db->set($data);
        $this->db->where('login_id',$id);
        $this->db->update("staff",$data);

         $this->db->set($login);
        $this->db->where('id',$id);
        $this->db->update("login",$login);


                       $notification=array(
                              'message'=>'Staff Information Updated Successful',
                              'alert-type'=>'success'
                            );
                            $this->session->set_flashdata($notification);
                            redirect('staff');

    }




public   function disable_member()
    {       
        $id=$this->input->post("txtid");
        $login = array(
            'status' =>1 // $this->input->post('status')
             );
        // var_dump($id); die;
         $this->db->set($login);
        $this->db->where('id',$id);
        $this->db->update("login",$login);

                       $notification=array(
                              'message'=>'Staff Disabled Successful',
                              'alert-type'=>'success'
                            );
                            $this->session->set_flashdata($notification);
                            redirect('staff');

    }

    public   function activate_member()
    {       
        $id=$this->input->post("txtid");
        $login = array(
            'status' =>0 // $this->input->post('status')
             );
        // var_dump($id); die;
         $this->db->set($login);
        $this->db->where('id',$id);
        $this->db->update("login",$login);

                       $notification=array(
                              'message'=>'Staff Activated Successful',
                              'alert-type'=>'success'
                            );
                            $this->session->set_flashdata($notification);
                            redirect('staff');

    }

     public   function delete_member()
    {       
        $id=$this->input->post("txtid");
        $data = array(
            'status' =>2 // $this->input->post('status')
             );
        // var_dump($id); die;
        $this->db->set($data);
        $this->db->where('id',$id);
        $this->db->update("login",$data);

        $this->db->set($data);
        $this->db->where('login_id',$id);
        $this->db->update("staff",$data);

                       $notification=array(
                              'message'=>'Staff Deleted Successful',
                              'alert-type'=>'success'
                            );
                            $this->session->set_flashdata($notification);
                            redirect('staff');

    }



public function index11()
    {

        if($this->session->userdata('logged_in'))
        {
            $session_data = $this->session->userdata('logged_in');
            $dashboard['usersfullname'] = $session_data['usersfullname'];
            $dashboard['useremail'] = $session_data['useremail'];
            $dashboard['logintoken'] = $session_data['logintoken'];


            //  $users['roles']=$this->all_roles(); 
            // $users['all_Business']=$this->all_Business();
            

             $users['active']='onboarding';
            $this->load->view('FIOnboarding',$users);


            

              }
        else
        {
        //If no session, redirect to login page
        redirect('login', 'refresh');
        }

    }
 public function all_roles()
    {
        $query= $this->db->query("select rolename from roles ");
        $users= $query->result();
        return $users;
    }
    public function AddBusiness()
    {
       $contact = $this->input->post('Admincontact');
        $password=hash('sha512',$contact);
        $data = array(
            'Adminfullname' =>$this->input->post('Adminfullname'),
            'Adminemail' => $this->input->post('Adminemail'),
            'Admincontact' => $this->input->post('Admincontact'),
            'Bname' => $this->input->post('Bname'), 
            'Btype' => $this->input->post('Btype'),
            'BdigitalAddress' => $this->input->post('BdigitalAddress'),
            'Bcontact' => $this->input->post('Bcontact'),
            'Bemail' => $this->input->post('Bemail'),
            'createddate' => date("Y-m-d"),
            'RegisteredEmployees'=>1,
            'Bstatus'=>'A',
        );

         $this->db->insert('Business', $data);

        $dataUser = array(
            'fullName' =>$this->input->post('Adminfullname'),
            'userEmail' => $this->input->post('Adminemail'),
            'phoneNumber' => $this->input->post('Admincontact'),
            'userRole' => 'BAdmin', 
            'createddate' => date("Y-m-d"),
            'passwordd'=>$password,
            'statuss'=>'A',
        );

        //var_dump($dataUser); die;
        $this->db->insert('users', $dataUser);

        redirect('onboarding');

    }

 public function sendMail()
        {


        //     $this->load->config('email');
        //     $this->load->library('email');
        
        // $from = $this->config->item('smtp_user');
        // $to = $this->input->post('to');





        $config = array(
    'protocol' => 'smtp', // 'mail', 'sendmail', or 'smtp'
    'smtp_host' => 'smtp.gmail.com', 
    'smtp_port' => 465,
    'smtp_user' => 'emmagbin@gmail.com',
    'smtp_pass' => '0249273086',
    'smtp_crypto' => 'ssl', //can be 'ssl' or 'tls' for example
    'mailtype' => 'text', //plaintext 'text' mails or 'html'
    'smtp_timeout' => '300', //in seconds
    'charset' => 'iso-8859-1',
    'wordwrap' => TRUE
);
        $this->load->library('Email');
        
        $from = $this->config->item('smtp_user');
        $to = 'emmagbin@yahoo.com';
        $subject ='hii';// $this->input->post('subject');
        $message = 'loo magbin';//$this->input->post('message');

        $this->email->set_newline("\r\n");
        $this->email->from($from);
        $this->email->to($to);
        $this->email->subject($subject);
        $this->email->message($message);

        if ($this->email->send()) {
            echo 'Your Email has successfully been sent.';
        } else {
           echo show_error($this->email->print_debugger());
        }
        die;


         //    $from_email = "PSKonnectAlert@gmail.com"; 
         // $to_email = 'emmagbin@yahoo.com';//$this->input->post('email'); 
   
         // //Load email library 
         // $this->load->library('email'); 
   
         // $this->email->from($from_email, 'emmagbin'); 
         // $this->email->to($to_email);
         // $this->email->subject('Email Test'); 
         // $this->email->message('Testing the email class.'); 
   
         // //Send mail 
         // if($this->email->send()) {
         //    echo 'Mail Successful Sent';
         //    die; 
         // }
        
         // else {
         //    echo 'Mail Successful Not Sent';
         //    die; 
         // }
         
 //echo ('hii'); die;
        // $query= $this->db->query("select CompanyName from t_CompanyRegistration where CompanyID='$mycompanyname'");
        //  $data= $query->result_array();
        //  $mycompanyname1=$data;
        //  $companyname=$mycompanyname1[0]['CompanyName'];

        // $email_to='emmagbin@yahoo.com';//$myemailaddress;//$this->input->post("resetingpass");



        // //require_once('PHPMailer/PHPMailerAutoload.php');
        //  require_once(APPPATH.'third_party/PHPMailer/PHPMailerAutoload.php');
        
        // $mail = new PHPMailer();
        // $mail->IsSMTP(); // we are going to use SMTP
        // $mail->SMTPAuth   = true; // enabled SMTP authentication
        // $mail->SMTPSecure = "ssl";  // prefix for secure protocol to connect to the server
        // $mail->Host       = "smtp.gmail.com";      // setting GMail as our SMTP server
        // $mail->Port       = 465;                   // SMTP port to connect to GMail
        // $mail->Username   = "PSKonnectAlert@gmail.com";  // user email address
        // $mail->Password   = "0249273086";            // password in GMail
        // $mail->SetFrom('PSKonnectAlert@gmail.com', 'Firm Anchor Consult');  //Who is sending
        // $mail->isHTML(true);
        // $mail->Subject    = "Registration Details";
        // $mail->Body      = "
        //     <html>
        //      <head>
                
        //     </head>
        //     <body>
        //     <h3>Welcome to Firm Anchor Consult: Magbin Immanuel   </h3>
        //     <p>Your Staff Identification Number is : 0249273086</p><br>
        //     <p>Your Company Email Address is : magbin</p><br>
        //     <p>To Log on to Nordcom Self Service system, click the URL below and follow prompts</p>
        //     <p>http://172.16.1.24:800/erpsystems/</p><br>
        //     <p>Your UserName is : emmagbin </p><br>
        //     <p>Your Default Password is : emailaddress </p><br>
        //     </body>
        //     </html>
        // ";
      
        // $mail->SMTPOptions = array(
        //             'ssl' => array(
        //             'verify_peer' => false,
        //             'verify_peer_name' => false,
        //             'allow_self_signed' => true
        //             )
        //             );
        // $destino = 'emmagbin@yahoo.com';//$email_to;//"emmagbin@yahoo.com"; // Who is addressed the email to
        // $mail->addAddress($destino, "Receiver");
        
        // if(!$mail->Send()) {
        //   echo 'Mailer Error:'.$mail->ErrorInfo;
            
        //     die;
        //     redirect('emplist');
        // } else {
            
        //     echo 'Mail Successful Sent';
        //     die;
        //     redirect('emplist');
        // }
        }


public function all_Business()
        {
            $query= $this->db->query("select * from Business");
             $all_Business= $query->result();
        return $all_Business;
        }











    public   function delete()
    {
        $id=$this->input->post("user_email");
        $data=array(
            'delete_flag'=>'Y'
        );
        $this->db->set($data);
        $this->db->where('user_email',$id);
        $this->db->update("users",$data);
        redirect('create_user');
    }




    public   function update()
    {
        $id=$this->input->post("user_email");
       // var_dump($id); die;
        $data = array(
            'user_full_name' => $this->input->post('user_full_name'),
             'gender' => $this->input->post('gender'),
              'phonenumber' => $this->input->post('phonenumber')
            
             );

        $this->db->set($data);
        $this->db->where('user_email',$id);
        $this->db->update("users",$data);
        redirect('create_user');

    }

    public function change_password()
{
        $password=$this->input->post("password");
        $new_pass=$this->input->post("new_pass");
        $new_pass_confirm=$this->input->post("new_pass_confirm");
        $user_email=$this->input->post("user_email");

             $pass=hash('sha512',$password);  
        //var_dump($user_email); die;
         $result=$this->validate_old_password($pass,$user_email);
         //var_dump($result); die();
             if($result=='1')
               {
                            if($new_pass==$new_pass_confirm)
                        {

                                            $data = array('password' => hash('sha512', $new_pass) );
                                            $this->db->set($data);
                                            $this->db->where('user_email',$user_email);
                                           $this->db->update("users",$data);

                            echo $result;
                        }
                        else
                        {
                                //return 2;
                                $result=2;
                                echo $result;
                        }


                        // $result=$this->compare_password($new_pass,$new_pass_confirm);

                            //var_dump($result); die;
                                //  if($result=='1')
                                    //{

                            //          $this->db->query("update users set password='$pass' where user_email='$user_email' "); 
                            //               $data = array('password' => $pass );
                            //                echo $user_email; die;
                            //                  $this->db->set($data);
                                           // $this->db->where('user_email',$user_email);
                                           // $this->db->update("users",$data);
                                           //  redirect('ServiceCategory');
                                        //$result=1;

                                    //ima@ite.comWednesday
                                       //     echo $result;   
                                    //}
                                    //else
                                    //{
                                    //  $result=='2';
                                    //  echo $result;
                                    //}
                                
               }
               else{ 
                    echo $result;
                }

    
}
        public function validate_old_password($pass,$user_email)
        {
            $query=$this->db->query("select password from users where password='$pass' and user_email='$user_email' "); 
                   $result=$query->num_rows();
                if($result >=1)
                {
                        return 1;
                }
                else
                {
                        return 0;
                }
        }

public function add_description()
        {
            $data = array(
                'transaction_id' => $this->input->post('transaction_id'),
                'descriptions' => $this->input->post('descriptions'),
                'time_date' => date("Y-m-d H:i:s")
                );
            
             $this->db->insert('case_description', $data);
            $result=1;
             echo $result;
                //redirect('case');
        }
}

