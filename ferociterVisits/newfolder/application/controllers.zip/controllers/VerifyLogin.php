<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class VerifyLogin extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('user', '', TRUE);
    }

    function index()
    {

        //This method will have the credentials validation
        $this->load->library('form_validation');
        $this->form_validation->set_rules('username', 'Username', 'trim|required');
        $this->form_validation->set_rules('password', 'Password', 'trim|required|callback_check_database');

        if ($this->form_validation->run() == FALSE) {
            //Field validation failed.  User redirected to login page
           // $this->load->view('login');
           // redirect('login', 'refresh');

            $page['page'] = 'login';
            $this->load->view('website/head', $page);
            $this->load->view('website/' . $page['page']);
            $this->load->view('website/footer');


        } else {
            if ($this->session->userdata('logged_in')) {
                

                $session_data = $this->session->userdata('logged_in');
                $mysessionInformation['role'] = $session_data['role'];

               // var_dump($mysessionInformation['role']); die;
                $sessionDataCheck = strlen($mysessionInformation['role']);
                if ($sessionDataCheck > 0) {


                    redirect('home', 'refresh');
                } else {
                    //Go to private area
                    redirect('login', 'refresh');
                }
            }
        }
    }

    function check_database($password)
    {
        //Field validation succeeded.  Validate against database
        $username = $this->input->post('username');

        //query the database

        $passwordCombination = $username . $password;
        $passwordToken = hash('sha512', $passwordCombination);
   

        // $g=hash('sha512',$password; );
        $result = $this->user->login($passwordToken);

        if ($result) {
            $sess_array = array();


            foreach ($result as $row) {

            $usersid = $row->id;
            $usersrole= $row->role;
            
            if($usersrole=="jobseeker"){
               $query= $this->db->query("select CONCAT(firstname, '  ', lastname) AS fullname  FROM jobseeker
                where login_id='$usersid' ");
               $Systemuser= $query->result_array();

            }else{

               $query= $this->db->query("select CONCAT(firstname, '  ', lastname) AS fullname  FROM staff where login_id='$usersid' ");
               $Systemuser= $query->result_array();

            }


            $query= $this->db->query("select photo as photo  FROM jobseeker
                where login_id='$usersid' ");
               $Systemuserphoto= $query->result_array();

           
            // var_dump($Systemuser); die;



                $sess_array = array(

                    'id' => $row->id,
                    'email' => $row->email,
                    'role' => $row->role,
                    'Systemuser' => $Systemuser,
                    'Systemuserphoto'=>$Systemuserphoto,
                );
                $this->session->set_userdata('logged_in', $sess_array);
            }
            return TRUE;
        } else {
            $this->form_validation->set_message('check_database', 'Invalid credentials');
            return false;
        }
    }
}
