
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Jobseeker_Controller extends CI_Controller {
 
public function __construct()
	 	{
	 		parent::__construct();
			$this->load->helper('url');
	 	}



public function applications11()
    {
       $page['page'] = 'applications';
         $this->load->view('admin/' . $page['page']);
    }

 public function all_applications($userid)
{
    $query= $this->db->query("select jobdetial.*,jobapplications.created_at as myapplieddate FROM `jobdetial`inner join jobapplications  on jobdetial.id=jobapplications.job_id inner join jobseeker on jobseeker.login_id=jobapplications.jobseeker_id where   jobapplications.jobseeker_id='$userid'
");

    $all_applicants= $query->result();
    return $all_applicants;
}

 public function applications()
    {
              if($this->session->userdata('logged_in'))
        {

            $session_data = $this->session->userdata('logged_in');
            $applications['id'] = $session_data['id'];
            $applications['email'] = $session_data['email'];
          
            $applications['role'] = $session_data['role'];

            $userid = $session_data['id'];

 if($applications['email']!=='admin@gmail.com')
          {

             $user['Systemuser'] = $session_data['Systemuser'];
            $myname=$user['Systemuser']['0']["fullname"];
            $applications['Systemuser'] =$myname;

            $user['Systemuserphoto'] = $session_data['Systemuserphoto'];
            $myphoto=$user['Systemuserphoto']['0']["photo"];
            $applications['Systemuserphoto'] =$myphoto;

             }
            else
            {
            $applications['Systemuser'] ='System Administrator';
            $applications['Systemuserphoto'] =0;

            }

       
            $applications['applications']=$this->all_applications($userid);
           // var_dump($applicants['applicants']); die;
            $page['page'] = 'applications';
         $this->load->view('admin/' . $page['page'], $applications);

         //  $page['page'] = 'applications';
         // $this->load->view('admin/' . $page['page']);

        }
        else
        {
        //If no session, redirect to login page
        redirect('login', 'refresh');
        }
    }

public function jobseeker_profile($userid)
{
    $query= $this->db->query("select jobseeker.*, login.email from jobseeker inner join login on jobseeker.login_id=login.id where jobseeker.login_id='$userid' ");

    $profile= $query->result();
    return $profile;
}


    public function profile()
    {
        if($this->session->userdata('logged_in'))
        {

            $session_data = $this->session->userdata('logged_in');
            $profile['id'] = $session_data['id'];
            $profile['email'] = $session_data['email'];
            $profile['role'] = $session_data['role'];

            $userid = $session_data['id'];

             if($profile['email']!=='admin@gmail.com')
          {

             $user['Systemuser'] = $session_data['Systemuser'];
            $myname=$user['Systemuser']['0']["fullname"];
            $profile['Systemuser'] =$myname;

            $user['Systemuserphoto'] = $session_data['Systemuserphoto'];
            $myphoto=$user['Systemuserphoto']['0']["photo"];
            $profile['Systemuserphoto'] =$myphoto;

             }
            else
            {
            $applications['Systemuser'] ='System Administrator';
            $profile['Systemuserphoto'] =0;

            }

          $profile['profile']=$this->jobseeker_profile($userid);

          //var_dump($profile['profile']);die;
         $page['page'] = 'profile';
         $this->load->view('admin/' . $page['page'],$profile);



        }
        else
        {
        //If no session, redirect to login page
        redirect('login', 'refresh');
        }

    }



public function updateProfilePic()
        {

           if($this->session->userdata('logged_in'))
        {

            $session_data = $this->session->userdata('logged_in');
            $applications['id'] = $session_data['id'];
            $applications['email'] = $session_data['email'];
            $applications['role'] = $session_data['role'];
            $userid = $session_data['id'];

                $config['file_name']        =  $userid ;
                $config['upload_path']          = './assets/profile';
                $config['allowed_types']        = 'jpeg|jpg|png';
                $config['max_size']             = 1000000;
                $config['max_width']            = 1024;
                $config['max_height']           = 768;

             $oldphoto=$this->input->post('oldphoto');
             // var_dump($oldphoto); die;



                $filename = './assets/profile/'.$oldphoto;
                if (file_exists($filename)) {

                 // echo('yes'); die;
                  rename("./assets/profile/".$oldphoto,"./assets/profile/"."newname".$oldphoto);
                } 


                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('profileavatar'))
                {

                   rename("./assets/profile/"."newname".$oldphoto,"./assets/profile/".$oldphoto);
                        // $error = array('error' => $this->upload->display_errors());

                        $error = array('error' => $this->upload->display_errors());
                           $notification=array(
                              'message'=>$error['error'],
                              'alert-type'=>'info'
                            );
                            $this->session->set_flashdata($notification);
                            redirect('profile');
                }
                else
                {

                  $data = array('upload_data' => $this->upload->data());
                  $photo=($data['upload_data']['file_ext']); 
                  $myphoto=$userid.$photo;


                        $data=array(
                            'photo'=>$myphoto
                        );
                        $this->db->set($data);
                        $this->db->where('login_id',$userid);
                        $this->db->update("jobseeker",$data);

                        unlink("./assets/profile/"."newname".$oldphoto);

                           $notification=array(
                              'message'=>'Pix Uploaded Successful',
                              'alert-type'=>'success'
                            );
                            $this->session->set_flashdata($notification);
                            redirect('profile');
                }
        }

    }


             public function updateProfile()
        {

             if($this->session->userdata('logged_in'))
        {

            $session_data = $this->session->userdata('logged_in');
            $applications['id'] = $session_data['id'];
            $applications['email'] = $session_data['email'];
            $applications['role'] = $session_data['role'];
            $userid = $session_data['id'];

                        $data=array(
                            'lastname'=>$this->input->post('lastname'),
                            'firstname'=>$this->input->post('firstname'),
                            'othername'=>$this->input->post('othername'),
                            'gender'=>$this->input->post('gender'),
                            'contact1'=>$this->input->post('contact1'),
                            'contact2'=>$this->input->post('contact2'),
                            'homeaddress'=>$this->input->post('homeaddress'),
                            'location'=>$this->input->post('location'),
                             'dob'=>$this->input->post('dob')



                            
                        );
                        $this->db->set($data);
                        $this->db->where('login_id',$userid);
                        $this->db->update("jobseeker",$data);

                    $notification=array(
                              'message'=>'Profile Update Successful',
                              'alert-type'=>'success'
                            );
                            $this->session->set_flashdata($notification);
                            redirect('profile');
        }
              

        }

     public function updateProfileAccount()
        {

             if($this->session->userdata('logged_in'))
        {

            $session_data = $this->session->userdata('logged_in');
            $applications['id'] = $session_data['id'];
            $applications['email'] = $session_data['email'];
            $applications['role'] = $session_data['role'];
            $userid = $session_data['id'];

            $oldpassword=$this->input->post('oldpassword');
            $newpassword=$this->input->post('newpassword');
            $confirmpassword=$this->input->post('confirmpassword');

            if ( strlen($newpassword)>6 ||  strlen($confirmpassword)>6 )
              {
                if($newpassword==$confirmpassword)
                {

                  $passwordCombination = $session_data['email'] . $oldpassword;
                  $pass = hash('sha512', $passwordCombination);
                  $isLogin=1;

                $query=$this->db->query("select * from login where password='$pass' and isLogin='$isLogin' "); 
                $result=$query->num_rows();
                if($result==1){


                  $passwordCombination_new = $session_data['email'] . $newpassword;
                  $pass_new = hash('sha512', $passwordCombination_new);

                     $data=array(
                            'password'=>$pass_new
                        );
                        $this->db->set($data);
                        $this->db->where('id',$userid);
                        $this->db->update("login",$data);

                  $notification=array(
                              'message'=>'Account Update Successful',
                              'alert-type'=>'success'
                            );
                            $this->session->set_flashdata($notification);
                            redirect('profile');


                }else{

                  $notification=array(
                              'message'=>'Wrong Login Password',
                              'alert-type'=>'error'
                            );
                            $this->session->set_flashdata($notification);
                            redirect('profile');

                }

                }
                else{
                   $notification=array(
                              'message'=>'New Password Dont Match',
                              'alert-type'=>'error'
                            );
                            $this->session->set_flashdata($notification);
                            redirect('profile');
                }

              }  
              else{

                 $notification=array(
                              'message'=>'Passwords Length must Be Greater than 6',
                              'alert-type'=>'error'
                            );
                            $this->session->set_flashdata($notification);
                            redirect('profile');
              }

        }
  }





             public function updateProfileWork()
        {

             if($this->session->userdata('logged_in'))
        {

            $session_data = $this->session->userdata('logged_in');
            $applications['id'] = $session_data['id'];
            $applications['email'] = $session_data['email'];
            $applications['role'] = $session_data['role'];
            $userid = $session_data['id'];

                        $data=array(
                            'Profession'=>$this->input->post('Profession'),
                            'highestqualification'=>$this->input->post('highestqualification'),
                            'currentjob'=>$this->input->post('currentjob'),
                            'worktype'=>$this->input->post('worktype'),
                            'experience'=>$this->input->post('experience'),
                            'availability'=>$this->input->post('availability'),
                            'preferedjoblocation'=>$this->input->post('preferedjoblocation'),
                            'salaryexpectation'=>$this->input->post('salaryexpectation')
                        );
                        $this->db->set($data);
                        $this->db->where('login_id',$userid);
                        $this->db->update("jobseeker",$data);

                    $notification=array(
                              'message'=>'Work Profile Update Successful',
                              'alert-type'=>'success'
                            );
                            $this->session->set_flashdata($notification);
                            redirect('profile');
        }
              

        }


         public function do_upload()
        {
 if($this->session->userdata('logged_in'))
        {

            $session_data = $this->session->userdata('logged_in');
            $applications['id'] = $session_data['id'];
            $applications['email'] = $session_data['email'];
            $applications['role'] = $session_data['role'];
            $userid = $session_data['id'];

          


                $config['file_name']        =  $userid ;
                $config['upload_path']          = './assets/cvs';
                $config['allowed_types']        = 'pdf';
                $config['max_size']             = 1000000;
                $config['max_width']            = 1024;
                $config['max_height']           = 768;
                $filename = './assets/cvs/1.pdf';
                if (file_exists($filename)) {
                 // unlink("./assets/cvs/1.pdf");
                  rename("./assets/cvs/".$userid.".pdf","./assets/cvs/".$userid."newname".".pdf");
                } 
              $this->load->library('upload', $config);

                if (!$this->upload->do_upload('userfile'))
                {
                  // rename("./assets/cvs/1newname.pdf","./assets/cvs/1.pdf");
                   rename("./assets/cvs/".$userid."newname".".pdf","./assets/cvs/".$userid.".pdf");

                           $error = array('error' => $this->upload->display_errors());
                           $notification=array(
                              'message'=>$error['error'],
                              'alert-type'=>'info'
                            );
                            $this->session->set_flashdata($notification);
                            redirect('profile');
                }
                else
                {
                            $notification=array(
                              'message'=>"CV Uploaded Successful",
                              'alert-type'=>'success'
                            );
                            $this->session->set_flashdata($notification);
                          $data=array(
                            'cv'=>1
                        );
                        $this->db->set($data);
                        $this->db->where('login_id',$userid);
                        $this->db->update("jobseeker",$data);


                            unlink("./assets/cvs/".$userid."newname".".pdf");
                            redirect('profile');

                        
                }


        }





              

        }


public function index()
	{
 		if($this->session->userdata('logged_in'))
		{
               $session_data = $this->session->userdata('logged_in');
            $users['usersfullname'] = $session_data['usersfullname'];
            $users['email'] = $session_data['email'];
            $users['logintoken'] = $session_data['logintoken'];
            $users['finame'] = $session_data['finame'];
            $users['roles']=$this->all_roles(); 
             $users['active']='transaction';
             $users['reportdate']='TRANSACTION REPORT FOR ' .date('Y-m-d');

              $users['today_transactions']=$this->today_transactions();


			$this->load->view('transaction',$users);
	     }

	}


 public function all_roles()
    {
        $query= $this->db->query("select rolename from roles ");
        $users= $query->result();
        return $users;
    }

 public function today_transactions()
    {
        

         $query= $this->db->query("select (rolename)'rolename',(previledge)'previledge',createdby'createdby',
         (lastupdatedby)'lastupdatedby', (createdtime)'createdtime'
           from previledges where  createddate='2019-04-11'
      
      ");
        $today_dropOff= $query->result();
        return $today_dropOff;
    }


 public function range_summarytransactions()
    {
         
        $start_date=$this->input->post('from_date');
        $end_date=$this->input->post('to_date');

         //var_dump($end_date); die;
         $query = $this->db->query("select (rolename)'picker',(previledge)'kid',createdby'date',
         (lastupdatedby)'time', (createdtime)'receiver'
          from previledges   where createddate  between '$start_date' and '$end_date' ");
         $transaction = $query->result();
        echo json_encode($transaction);
    }


public function range_transactions_for_printing()
    {
        //$defaut=$this->input->post('start_date');

        $start_date=$this->input->post('from_date');
        $end_date=$this->input->post('to_date');

        //var_dump($start_date);die;
        $query = $this->db->query(" select (rolename)'picker',(previledge)'kid',createdby'date',
         (lastupdatedby)'time', (createdtime)'receiver'
          from previledges   where createddate  between '$start_date' and '$end_date' ");
        $weekly_summary = $query->result();

        $output = '';
        $output .=
            '<table class="table table-bordered" id="forprinting" >
                            <thead>
                                  <tr>
                                                          <th>rolename</th>
                                                            <th>previledge</th>
                                                            <th>createdby</th>
                                                            <th>lastupdatedby</th>
                                                             <th>createdtime</th>
                                    
                                   
                                </tr>
                            </thead>
               
                            ';

        //get count
        $result=$query->num_rows();
        //echo $result;
        if($result > 0)
        {
            //echo "heoll";
            foreach($weekly_summary as $record)
            {
                //var_dump($record);die;
                $output .= ' <tr>
                          <td>'. $record->date .'</td>
                          <td>'. $record->time .'</td>
                          <td>'. $record->kid .'</td>
                          <td>'. $record->picker .'</td>
                          <td>'. $record->receiver .'</td>
                          
                      
                          
                     </tr>
               ';
            }
        }
        else
        {
            $output .= '
                <tr>
                     <td colspan="5">No Records Found</td>
                </tr>
           ';
        }

        $output .= '</table>';
        //var_dump($output); die;
        echo $output;
        //echo $weekly_summary;
    }



	


}

