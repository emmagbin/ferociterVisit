
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class acountDetailController extends CI_Controller {
 
public function __construct()
	 	{
	 		parent::__construct();
			$this->load->helper('url');
	 	}

public function index()
	{
 		if($this->session->userdata('logged_in'))
		{
               $session_data = $this->session->userdata('logged_in');
            $users['usersfullname'] = $session_data['usersfullname'];
            $users['useremail'] = $session_data['useremail'];
            $users['logintoken'] = $session_data['logintoken'];
            $users['finame'] = $session_data['finame'];
            $fiName=$session_data['finame'];
           // var_dump($fiName); die;

        $query= $this->db->query("select * from fis where fiName='$fiName' ");
        $fiDetails= $query->result_array();
        //$users['fiDetails'][]=$fiDetails;
        $users['fiName']=$fiDetails[0]['fiName'];
        $users['fiType']=$fiDetails[0]['fiType'];
        $users['fiCode']=$fiDetails[0]['fiCode'];

        $users['orgDigitalAddress']=$fiDetails[0]['orgDigitalAddress'];
        $users['fiContact']=$fiDetails[0]['fiContact'];
        $users['fiMail']=$fiDetails[0]['fiMail'];
        $users['suspenseAccountNumber']=$fiDetails[0]['suspenseAccountNumber'];

        $users['adminEmail']=$fiDetails[0]['adminEmail'];
        $users['adminfullname']=$fiDetails[0]['adminfullname'];
        $users['adminContact']=$fiDetails[0]['adminContact'];

        $users['CreatedBy']=$fiDetails[0]['CreatedBy'];
        $users['CreatedOn']=$fiDetails[0]['CreatedOn'];
         $users['lastUpdatedOn']=$fiDetails[0]['lastUpdatedOn'];

         $users['fiStatus']=$fiDetails[0]['fiStatus'];
        // var_dump($users['fiStatus']); die;

         

         $users['roles']=$this->all_roles(); 



             $users['active']='acountDetail';
			$this->load->view('acountDetail',$users);
	     }

	}



 public function fisDetails()
    {
        //var_dump('fisDetail'); die;
        $fiName=$this->input->post('finame');
        $query= $this->db->query("select * from fis  where fiName='$fiName'");
        $fisDetails= $query->result_array();
       
        echo json_encode($fisDetails);
        
    }

     public function all_roles()
    {
        $query= $this->db->query("select rolename from roles ");
        $users= $query->result();
        return $users;
    }


 public function all_Agents()
    {
        $query= $this->db->query("select * from Agents ");
        $users= $query->result();
        return $users;
    }

	function addAgent()
	{

        $data = array(
            'AgfullName' =>$this->input->post('Agentname'),
            'AgGender' => $this->input->post('Agnetsex'),
            'AgPhoneNumber' => $this->input->post('Agentcontact'),
            'AgStatus' => 'A',
            'AgRegistrationDate' => date("Y-m-d"),
            'AgRegisteredBy' =>  $this->input->post('regby'),
            
        );

        //var_dump($data); die;
        $this->db->insert('Agents', $data);

        redirect('data');

	}

	


 public function editAgent()
    {
        $id=$this->input->post('txtidedit');
       $data = array(
            'AgfullName' =>$this->input->post('txtAgfullName'),
            'AgPhoneNumber' => $this->input->post('txtAgPhoneNumber'),
        );
        $this->db->set($data);
        $this->db->where('id',$id);
        $this->db->update("Agents",$data);
        redirect('data');
    }

    


public   function unlock()
    {
        $id=$this->input->post('id');
        //var_dump($id); die;
        $data=array(
            'AgStatus'=>'A'
        );
        $this->db->set($data);
        $this->db->where('id',$id);
        $this->db->update("Agents",$data);
        redirect('data');
    }

 public   function DisableAgent()
    {
        $id=$this->input->post('DisableAgentid');
        $data=array(
            'AgStatus'=>'D'
        );
      // var_dump($data); die;
        $this->db->set($data);
        $this->db->where('id',$id);
        $this->db->update("Agents",$data);
        redirect('data');
    }









	


















// CHANGING OF PASSWORD
    public function change_password()
{
		$password=$this->input->post("password");
		$new_pass=$this->input->post("new_pass");
		$new_pass_confirm=$this->input->post("new_pass_confirm");
		$user_email=$this->input->post("user_email");

		     $pass=hash('sha512',$password);  
        //var_dump($user_email); die;
         $result=$this->validate_old_password($pass,$user_email);
		 //var_dump($result); die();
             if($result=='1')
               {
		               		if($new_pass==$new_pass_confirm)
				        {

				        					$data = array('password' => hash('sha512', $new_pass) );
											$this->db->set($data);
									        $this->db->where('user_email',$user_email);
									       $this->db->update("users",$data);

				        	echo $result;
				        }
				        else
				        {
				                //return 2;
				                $result=2;
				               	echo $result;
				        }
               }
               else{ 
		        	echo $result;
                }

	
}
	
		//PASSWORD VALIDATION
		public function validate_old_password($pass,$user_email)
		{
		    $query=$this->db->query("select password from users where password='$pass' and user_email='$user_email' "); 
		           $result=$query->num_rows();
		        if($result >=1)
		        {
		                return 1;
		        }
		        else
		        {
		                return 0;
		        }
		}

}

